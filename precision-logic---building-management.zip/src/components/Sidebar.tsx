import { LayoutDashboard, Building2, Users, DoorOpen, FileBarChart } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

const navItems = [
  { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard', subLabel: 'OVERVIEW', href: '#' },
  { id: 'directory', icon: Building2, label: 'BUILDING DIRECTORY', subLabel: 'MANAGEMENT', href: '#' },
  { id: 'residents', icon: Users, label: 'RESIDENT LIST', subLabel: 'DATA', href: '#' },
  { id: 'rooms', icon: DoorOpen, label: 'ROOM INVENTORY', subLabel: 'STATUS', href: '#' },
  { id: 'reports', icon: FileBarChart, label: 'REPORTS', subLabel: 'ANALYTICS', href: '#' },
];

export default function Sidebar({ currentView, onNavigate }: SidebarProps) {
  return (
    <aside className="w-64 bg-surface-container-lowest border-r border-outline/20 h-screen flex flex-col fixed left-0 top-0">
      <div className="p-6">
        <h1 className="text-xl font-bold tracking-tight mb-0">MGE.BDG</h1>
      </div>
      
      <div className="px-6 py-4">
        <h2 className="text-sm font-bold text-on-surface tracking-wide mb-1">Management</h2>
        <p className="text-[10px] text-on-surface-variant font-medium tracking-widest uppercase mb-6">Building Operations</p>
        
        <nav className="space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-200 group text-left",
                currentView === item.id 
                  ? "bg-secondary text-on-secondary shadow-lg shadow-secondary/20" 
                  : "text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface"
              )}
            >
              <item.icon className={cn("w-5 h-5", currentView === item.id ? "text-on-secondary" : "text-on-surface-variant group-hover:text-on-surface")} />
              <div className="flex flex-col">
                <span className="text-xs font-semibold tracking-wide uppercase">{item.label}</span>
                {item.subLabel && <span className="text-[9px] opacity-70 font-bold uppercase tracking-tighter">{item.subLabel}</span>}
              </div>
              {currentView === item.id && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-on-secondary" />
              )}
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6 border-t border-outline/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center border border-outline/20">
            <Users className="w-5 h-5 text-primary" />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold">Admin User</span>
            <span className="text-[10px] text-on-surface-variant">Operations Manager</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
