import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { building: 'Bldg-101', score: 80 },
  { building: 'Bldg-102', score: 60 },
  { building: 'Bldg-103', score: 85 },
  { building: 'Bldg-104', score: 100 },
  { building: 'Bldg-105', score: 65 },
  { building: 'Bldg-106', score: 85 },
  { building: 'Bldg-107', score: 66 },
];

export default function HealthChart() {
  return (
    <div className="bg-surface-container-low border border-outline/20 rounded-xl p-6 h-full shadow-sm">
      <div className="mb-6">
        <h3 className="text-lg font-bold myanmar-text">Building Health Score</h3>
        <p className="text-xs text-on-surface-variant myanmar-text mt-1">ပြန်လည်ပြုပြင်ပြီးစီးမှုနှုန်းများကို တိုက်ခိုက်မည့် ကိန်းဂဏန်းအလိုက် ဖော်ပြရန်</p>
      </div>

      <div className="h-64 mt-4">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#64748B20" />
            <XAxis 
              dataKey="building" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#c6c6cd', fontSize: 10 }} 
              dy={10}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#c6c6cd', fontSize: 10 }}
              tickFormatter={(val) => `${val}%`}
            />
            <Tooltip 
              cursor={{ fill: '#64748B10' }}
              contentStyle={{ 
                backgroundColor: '#0b1c30', 
                border: '1px solid #64748B40', 
                borderRadius: '8px',
                fontSize: '12px',
                color: '#d3e4fe'
              }}
              itemStyle={{ color: '#bec6e0' }}
            />
            <Bar 
              dataKey="score" 
              radius={[4, 4, 0, 0]} 
              barSize={32}
              label={{ 
                position: 'top', 
                fill: '#d3e4fe', 
                fontSize: 10,
                formatter: (val: number) => `${val}%`
              }}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.score === 100 ? '#10B981' : '#2563EB'} 
                  fillOpacity={0.8}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
