import React, { useState } from 'react';
import { X, UserPlus, Save, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Resident } from '@/src/types';

interface ResidentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (resident: Omit<Resident, 'id'>) => void;
}

export default function ResidentModal({ isOpen, onClose, onSave }: ResidentModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    roomNumber: '',
    designation: '',
    phoneNumber: '',
    status: 'ACTIVE' as 'ACTIVE' | 'PENDING',
    photoUrl: 'https://i.pravatar.cc/150?u=' + Math.random()
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API delay
    setTimeout(() => {
      onSave(formData);
      setIsSubmitting(false);
      onClose();
      setFormData({
        name: '',
        roomNumber: '',
        designation: '',
        phoneNumber: '',
        status: 'ACTIVE',
        photoUrl: 'https://i.pravatar.cc/150?u=' + Math.random()
      });
    }, 800);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-surface-container-lowest/80 backdrop-blur-sm"
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-md bg-surface-container-low border border-outline/20 rounded-2xl shadow-2xl overflow-hidden"
          >
            <form onSubmit={handleSubmit}>
              <div className="p-6 border-b border-outline/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-secondary/10 rounded-lg">
                    <UserPlus className="w-5 h-5 text-secondary" />
                  </div>
                  <h3 className="text-lg font-bold myanmar-text">နေထိုင်သူအသစ် ထည့်သွင်းရန်</h3>
                </div>
                <button type="button" onClick={onClose} className="p-2 hover:bg-surface-container-high rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-on-surface-variant uppercase tracking-widest myanmar-text">အမည် (Name)</label>
                  <input 
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-surface-container-high border border-outline/30 rounded-lg px-4 py-2.5 text-sm outline-none focus:border-secondary transition-colors"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-on-surface-variant uppercase tracking-widest myanmar-text">အခန်းနံပါတ်</label>
                    <input 
                      required
                      placeholder="e.g. A-101"
                      value={formData.roomNumber}
                      onChange={e => setFormData({ ...formData, roomNumber: e.target.value })}
                      className="w-full bg-surface-container-high border border-outline/30 rounded-lg px-4 py-2.5 text-sm outline-none focus:border-secondary transition-colors"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-on-surface-variant uppercase tracking-widest myanmar-text">ဖုန်းနံပါတ်</label>
                    <input 
                      required
                      value={formData.phoneNumber}
                      onChange={e => setFormData({ ...formData, phoneNumber: e.target.value })}
                      className="w-full bg-surface-container-high border border-outline/30 rounded-lg px-4 py-2.5 text-sm outline-none focus:border-secondary transition-colors"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-on-surface-variant uppercase tracking-widest myanmar-text">ရာထူး / တာဝန်</label>
                  <input 
                    required
                    value={formData.designation}
                    onChange={e => setFormData({ ...formData, designation: e.target.value })}
                    className="w-full bg-surface-container-high border border-outline/30 rounded-lg px-4 py-2.5 text-sm outline-none focus:border-secondary transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-on-surface-variant uppercase tracking-widest myanmar-text">အခြေအနေ</label>
                  <select 
                    value={formData.status}
                    onChange={e => setFormData({ ...formData, status: e.target.value as 'ACTIVE' | 'PENDING' })}
                    className="w-full bg-surface-container-high border border-outline/30 rounded-lg px-4 py-2.5 text-sm outline-none focus:border-secondary transition-colors"
                  >
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="PENDING">PENDING</option>
                  </select>
                </div>
              </div>

              <div className="p-6 border-t border-outline/10 bg-surface-container/30 flex justify-end gap-3">
                <button 
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2 rounded-lg text-xs font-bold hover:bg-surface-container-high transition-colors"
                  disabled={isSubmitting}
                >
                  CANCEL
                </button>
                <button 
                  type="submit"
                  className="flex items-center gap-2 px-6 py-2 bg-secondary text-on-secondary rounded-lg text-xs font-bold hover:opacity-90 transition-all shadow-lg shadow-secondary/20 disabled:opacity-50"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  SAVE RESIDENT
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
