import React, { useState } from 'react';
import { MoreVertical, Edit2, Trash2, Filter, Plus, Search, X } from 'lucide-react';
import { Resident } from '@/src/types';
import { cn } from '@/src/lib/utils';
import ResidentModal from './ResidentModal';
import ConfirmModal from './ConfirmModal';
import { motion, AnimatePresence } from 'motion/react';

const INITIAL_RESIDENTS: Resident[] = [
  { id: '1', roomNumber: 'A-101', name: 'ဦးကျော်မင်းဦး', designation: 'ညွှန်ကြားရေးမှူး', phoneNumber: '၀၉-၄၄၅ ၅၆၆ ၇၇၈', status: 'ACTIVE', photoUrl: 'https://i.pravatar.cc/150?u=1' },
  { id: '2', roomNumber: 'B-205', name: 'ဒေါ်အေးအေးသင်း', designation: 'ဌာနမှူး', phoneNumber: '၀၉-၇၇၈ ၈၈၉ ၉၉၀', status: 'ACTIVE', photoUrl: 'https://i.pravatar.cc/150?u=2' },
  { id: '3', roomNumber: 'C-310', name: 'ဦးဇော်လင်း', designation: 'လက်ထောက်ညွှန်ကြားရေးမှူး', phoneNumber: '၀၉-၂၂၃ ၃၃၄ ၄၅၅', status: 'PENDING', photoUrl: 'https://i.pravatar.cc/150?u=3' },
  { id: '4', roomNumber: 'A-402', name: 'ဒေါ်စုလှိုင်', designation: 'အကြီးတန်းအရာရှိ', phoneNumber: '၀၉-၁၁၂ ၂၂၃ ၃၄၄', status: 'ACTIVE', photoUrl: 'https://i.pravatar.cc/150?u=4' },
];

export default function ResidentTable() {
  const [residents, setResidents] = useState<Resident[]>(INITIAL_RESIDENTS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'PENDING'>('ALL');

  const filteredResidents = residents.filter(r => {
    const matchesSearch = r.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         r.roomNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || r.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleAddResident = (newResident: Omit<Resident, 'id'>) => {
    const residentWithId: Resident = {
      ...newResident,
      id: Math.random().toString(36).substr(2, 9)
    };
    setResidents([residentWithId, ...residents]);
  };

  const confirmDelete = () => {
    if (deleteConfirm.id) {
      setResidents(residents.filter(r => r.id !== deleteConfirm.id));
      setDeleteConfirm({ isOpen: false, id: null });
    }
  };

  const getResidentName = (id: string | null) => {
    return residents.find(r => r.id === id)?.name || '';
  };

  return (
    <div className="bg-surface-container-low border border-outline/20 rounded-xl overflow-hidden shadow-sm">
      <ConfirmModal 
        isOpen={deleteConfirm.isOpen}
        onClose={() => setDeleteConfirm({ isOpen: false, id: null })}
        onConfirm={confirmDelete}
        title="ဖျက်သိမ်းရန် သေချာပါသလား?"
        message={`"${getResidentName(deleteConfirm.id)}" ကို နေထိုင်သူများစာရင်းမှ အပြီးတိုင် ဖျက်ပစ်တော့မှာလား? ဤလုပ်ဆောင်ချက်ကို ပြန်ပြင်၍မရပါ။`}
        confirmLabel="DELETE RESIDENT"
      />

      <ResidentModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSave={handleAddResident} 
      />

      <div className="p-6 border-b border-outline/10 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold myanmar-text">နေထိုင်သူများ စာရင်း (Resident List)</h3>
            <p className="text-xs text-on-surface-variant myanmar-text">အဆောက်အဦ-၀၀၁ ရှိ လက်ရှိနေထိုင်သူများ</p>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 border border-outline/30 rounded-lg text-xs font-semibold transition-all myanmar-text",
                showFilters ? "bg-secondary text-on-secondary border-secondary" : "hover:bg-surface-container-high"
              )}
            >
              <Filter className="w-4 h-4" />
              စစ်ထုတ်ရန်
            </button>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-secondary text-on-secondary rounded-lg text-xs font-semibold hover:opacity-90 shadow-lg shadow-secondary/20 myanmar-text"
            >
              <Plus className="w-4 h-4" />
              အသစ်ထည့်ရန်
            </button>
          </div>
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="pt-4 grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-outline/10">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
                  <input 
                    type="text" 
                    placeholder="အမည် သို့မဟုတ် အခန်းနံပါတ်ဖြင့် ရှာဖွေရန်..." 
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full bg-surface-container-high border border-outline/30 rounded-lg py-2 pl-10 pr-4 text-xs focus:border-secondary outline-none transition-colors myanmar-text"
                  />
                </div>
                <div className="flex gap-2">
                  {(['ALL', 'ACTIVE', 'PENDING'] as const).map(status => (
                    <button 
                      key={status}
                      onClick={() => setStatusFilter(status)}
                      className={cn(
                        "flex-1 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest border transition-all",
                        statusFilter === status 
                          ? "bg-secondary/10 text-secondary border-secondary/30" 
                          : "border-outline/20 text-on-surface-variant hover:bg-surface-container-high"
                      )}
                    >
                      {status}
                    </button>
                  ))}
                  <button 
                    onClick={() => { setSearchQuery(''); setStatusFilter('ALL'); }}
                    className="p-2 border border-outline/20 rounded-lg text-on-surface-variant hover:text-error transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="overflow-x-auto min-h-[300px]">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-surface-container text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">
              <th className="px-6 py-4">အခန်းနံပါတ်</th>
              <th className="px-6 py-4">အမည်</th>
              <th className="px-6 py-4">ရာထူး</th>
              <th className="px-6 py-4">ဖုန်းနံပါတ်</th>
              <th className="px-6 py-4">အခြေအနေ</th>
              <th className="px-6 py-4 text-center">လုပ်ဆောင်ချက်</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-outline/10">
            {filteredResidents.length > 0 ? (
              filteredResidents.map((resident) => (
                <tr key={resident.id} className="hover:bg-surface-container-high/50 transition-colors group">
                  <td className="px-6 py-4">
                    <span className="text-xs font-bold text-secondary">{resident.roomNumber}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-surface-container-highest bg-surface-container">
                        <img src={resident.photoUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                      <span className="text-sm font-semibold myanmar-text">{resident.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs text-on-surface-variant myanmar-text">{resident.designation}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-mono">{resident.phoneNumber}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide",
                      resident.status === 'ACTIVE' 
                        ? "bg-tertiary/10 text-tertiary border border-tertiary/20" 
                        : "bg-error/10 text-error border border-error/20"
                    )}>
                      {resident.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-1.5 hover:bg-surface-container-highest rounded transition-colors text-on-surface-variant hover:text-secondary">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setDeleteConfirm({ isOpen: true, id: resident.id })}
                        className="p-1.5 hover:bg-surface-container-highest rounded transition-colors text-on-surface-variant hover:text-error"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-surface-container-highest rounded transition-colors text-on-surface-variant">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-20 text-center">
                  <div className="flex flex-col items-center gap-2 opacity-40">
                    <Search className="w-12 h-12" />
                    <p className="text-sm font-semibold myanmar-text">ဒေတာ မရှိပါ</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="p-4 border-t border-outline/10 flex items-center justify-between bg-surface-container/30">
        <span className="text-[10px] text-on-surface-variant font-medium">
          Showing {filteredResidents.length} entries
        </span>
        <div className="flex items-center gap-1">
          <button className="w-8 h-8 flex items-center justify-center rounded border border-outline/20 text-xs hover:bg-surface-container-high disabled:opacity-50">‹</button>
          <button className="w-8 h-8 flex items-center justify-center rounded bg-secondary text-on-secondary text-xs font-bold">၁</button>
          <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-surface-container-high text-xs border border-transparent">›</button>
        </div>
      </div>
    </div>
  );
}

