import { useState } from 'react';
import { Building, Users, Clock, FileSpreadsheet, Info } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import ExcelImportModal from './ExcelImportModal';

export default function DashboardOverview() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDataLoaded = (data: any[]) => {
    console.log('Imported Data:', data);
    // Here you would typically update the resident list state
  };

  return (
    <div className="space-y-6">
      <ExcelImportModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onDataLoaded={handleDataLoaded}
      />
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Dashboard Overview</h2>
          <p className="text-sm text-on-surface-variant myanmar-text text-muted-foreground font-medium">
            စီမံခန့်ခွဲမှုဆိုင်ရာ အကျဉ်းချုပ်
          </p>
        </div>

        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-surface-container-high border border-outline/30 px-4 py-3 rounded-lg hover:bg-surface-container-highest transition-colors group"
        >
          <div className="p-2 bg-surface-container rounded-md">
            <FileSpreadsheet className="w-5 h-5 text-tertiary" />
          </div>
          <div className="text-left">
            <span className="block text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">Excel</span>
            <span className="block text-xs font-semibold myanmar-text">ဒေတာများ ချိတ်ဆက်ရန်</span>
          </div>
        </button>
      </div>

      <div className="flex items-center gap-4">
        <span className="text-sm font-semibold myanmar-text">အဆောက်အဦအဆင့် (Building Level)</span>
        <div className="flex bg-surface-container-low p-1 rounded-lg border border-outline/20">
          <button className="px-6 py-2 bg-[#ef4444] text-white rounded-md text-sm font-bold shadow-md transition-all">အနီ (၁၅)</button>
          <button className="px-6 py-2 text-on-surface-variant hover:text-on-surface rounded-md text-sm font-bold transition-all">လိမ္မော် (၂၂)</button>
          <button className="px-6 py-2 text-on-surface-variant hover:text-on-surface rounded-md text-sm font-bold transition-all">အပြာ (၁၁)</button>
        </div>
        
        <div className="ml-auto flex items-center gap-2 text-sm">
          <span className="text-on-surface-variant myanmar-text">အဆောက်အဦ နံပါတ်</span>
          <div className="bg-surface-container-high px-3 py-1.5 rounded border border-outline/30 flex items-center gap-2 font-mono text-xs">
            အဆောက်အဦ - ၀၀၁
            <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Card 1 */}
        <div className="bg-surface-container-low border border-outline/20 p-6 rounded-xl space-y-4 hover:border-secondary/50 transition-colors">
          <div className="flex items-start justify-between">
            <div className="p-3 bg-secondary/10 rounded-xl">
              <Building className="w-8 h-8 text-secondary" />
            </div>
            <div className="text-right">
              <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-1">Total Rooms</p>
              <h3 className="text-3xl font-bold tracking-tight">၈၂၀ ခန်း</h3>
              <p className="text-xs text-tertiary font-medium mt-1">↗ ၄ ခန်း အသစ်တိုးသည်</p>
            </div>
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-surface-container-low border border-outline/20 p-6 rounded-xl space-y-4 hover:border-tertiary/50 transition-colors">
          <div className="flex items-start justify-between">
            <div className="p-3 bg-tertiary/10 rounded-xl">
              <Users className="w-8 h-8 text-tertiary" />
            </div>
            <div className="text-right">
              <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-1">Total Residents</p>
              <h3 className="text-3xl font-bold tracking-tight">၄၅၀ ဦး</h3>
              <p className="text-xs text-on-surface-variant/70 font-medium mt-1">ယခင်လထက် ၂% ပိုသည်</p>
            </div>
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-surface-container-low border border-outline/20 p-6 rounded-xl space-y-4 hover:border-error/50 transition-colors">
          <div className="flex items-start justify-between">
            <div className="p-3 bg-error/10 rounded-xl">
              <Clock className="w-8 h-8 text-error" />
            </div>
            <div className="text-right">
              <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-1">Pending Requests</p>
              <h3 className="text-3xl font-bold tracking-tight">၃၀ ဦး</h3>
              <p className="text-xs text-error font-medium mt-1">မြန်မြန်ဆန်ဆန် ဝန်ဆောင်မှုပေးရန်</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-secondary/10 border border-secondary/20 p-4 rounded-xl flex items-center gap-4">
        <div className="p-2 bg-secondary/20 rounded-lg">
          <Info className="w-5 h-5 text-secondary" />
        </div>
        <div className="flex-1">
          <p className="text-xs font-semibold myanmar-text">ဒေတာတင်သွင်းခြင်းဆိုင်ရာ လမ်းညွှန်ချက် (DATA MAPPING GUIDE)</p>
          <p className="text-[10px] text-on-surface-variant myanmar-text">Excel ဖိုင်တင်သွင်းရာတွင် အောက်ပါကော်လံများ ပါဝင်ရပါမည် - အဆောက်အဦနံပါတ်၊ အခန်းနံပါတ်၊ အမည် နှင့် ရာထူး။</p>
        </div>
        <div className="flex gap-2">
          {['Building No.', 'Room No.', 'Name', 'Designation'].map(label => (
            <div key={label} className="px-3 py-1 bg-surface-container-high border border-outline/30 rounded text-[10px] font-medium uppercase">
              {label}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
