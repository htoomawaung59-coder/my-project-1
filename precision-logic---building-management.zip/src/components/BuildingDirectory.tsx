import { Building2, MapPin, Users, DoorOpen, TrendingUp } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const buildings = [
  { id: '1', name: 'Building A', code: 'BLDG-A', location: 'North Wing', totalRooms: 200, residents: 145, health: 85 },
  { id: '2', name: 'Building B', code: 'BLDG-B', location: 'East Wing', totalRooms: 150, residents: 120, health: 92 },
  { id: '3', name: 'Building C', code: 'BLDG-C', location: 'South Wing', totalRooms: 300, residents: 185, health: 78 },
  { id: '4', name: 'Building D', code: 'BLDG-D', location: 'West Wing', totalRooms: 170, residents: 0, health: 100 },
];

export default function BuildingDirectory() {
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Building Directory</h2>
          <p className="text-sm text-on-surface-variant myanmar-text font-medium">
            အဆောက်အဦများ စာရင်းနှင့် အခြေအနေများကို ကြည့်ရှုရန်
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {buildings.map((building) => (
          <div key={building.id} className="bg-surface-container-low border border-outline/20 p-6 rounded-xl hover:border-secondary/50 transition-all group">
            <div className="flex justify-between items-start mb-6">
              <div className="p-3 bg-secondary/10 rounded-xl group-hover:bg-secondary/20 transition-colors">
                <Building2 className="w-8 h-8 text-secondary" />
              </div>
              <span className={cn(
                "px-2 py-1 rounded text-[10px] font-bold uppercase",
                building.health >= 90 ? "bg-tertiary/10 text-tertiary border border-tertiary/20" : "bg-warning/10 text-warning border border-warning/20"
              )}>
                Health: {building.health}%
              </span>
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-bold">{building.name}</h3>
              <div className="flex items-center gap-1 text-xs text-on-surface-variant mt-1">
                <MapPin className="w-3 h-3" />
                {building.location}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-outline/10">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">
                  <DoorOpen className="w-3 h-3" /> Rooms
                </div>
                <p className="text-sm font-bold">{building.totalRooms}</p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">
                  <Users className="w-3 h-3" /> Residents
                </div>
                <p className="text-sm font-bold">{building.residents}</p>
              </div>
            </div>
            
            <button className="w-full mt-6 py-2 bg-surface-container-high rounded-lg text-xs font-semibold hover:bg-secondary hover:text-on-secondary transition-all myanmar-text">
              အသေးစိတ်ကြည့်ရန်
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
