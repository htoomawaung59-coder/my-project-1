import React from 'react';
import { X, AlertTriangle, Trash2, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'warning';
}

export default function ConfirmModal({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = 'CONFIRM',
  cancelLabel = 'CANCEL',
  variant = 'danger'
}: ConfirmModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-surface-container-lowest/80 backdrop-blur-sm"
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-sm bg-surface-container-low border border-outline/20 rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="p-6 text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-error/10 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="w-8 h-8 text-error" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-xl font-bold myanmar-text">{title}</h3>
                <p className="text-sm text-on-surface-variant myanmar-text leading-relaxed">
                  {message}
                </p>
              </div>
            </div>

            <div className="p-6 border-t border-outline/10 bg-surface-container/30 flex flex-col gap-2">
              <button 
                onClick={onConfirm}
                className="w-full py-3 bg-error text-white rounded-lg text-xs font-bold hover:opacity-90 transition-all shadow-lg shadow-error/20 flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                {confirmLabel}
              </button>
              <button 
                onClick={onClose}
                className="w-full py-3 rounded-lg text-xs font-bold text-on-surface-variant hover:bg-surface-container-high transition-colors"
              >
                {cancelLabel}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
