import { Wrench, CheckCircle, Clock } from 'lucide-react';
import { MaintenanceTask } from '@/src/types';

const tasks: MaintenanceTask[] = [
  { id: '1', title: 'ရေပိုက်ပြင်ဆင်ရန်', room: 'Room B-205', time: 'Today', status: 'OPEN' },
  { id: '2', title: 'မီးလုံးစစ်ဆေးရန်', room: 'Main Hall', time: 'Tomorrow', status: 'OPEN' },
];

export default function MaintenanceTasks() {
  return (
    <div className="bg-surface-container-low border border-outline/20 rounded-xl p-6 h-full shadow-sm">
      <h3 className="text-lg font-bold myanmar-text mb-6">ပြုပြင်ထိန်းသိမ်းမှု လုပ်ငန်းများ (Maintenance Tasks)</h3>
      
      <div className="space-y-4">
        {tasks.map((task) => (
          <div key={task.id} className="bg-surface-container p-4 rounded-lg flex items-center justify-between group hover:border-secondary/30 border border-transparent transition-all">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-secondary/10 rounded-lg group-hover:scale-110 transition-transform">
                <Wrench className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <h4 className="text-sm font-semibold myanmar-text">{task.title}</h4>
                <p className="text-[10px] text-on-surface-variant myanmar-text">{task.room} • {task.time}</p>
              </div>
            </div>
            
            <span className="px-2 py-1 bg-surface-container-high text-on-surface-variant text-[10px] font-bold rounded uppercase">
              {task.status}
            </span>
          </div>
        ))}
      </div>
      
      <button className="w-full mt-6 py-3 text-xs font-semibold text-secondary hover:bg-secondary/10 rounded-lg transition-colors border border-dashed border-secondary/30 uppercase tracking-wider">
        View All Tasks
      </button>
    </div>
  );
}
