import React, { useState, useRef } from 'react';
import { X, Upload, FileSpreadsheet, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import * as XLSX from 'xlsx';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface ExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataLoaded: (data: any[]) => void;
}

export default function ExcelImportModal({ isOpen, onClose, onDataLoaded }: ExcelImportModalProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    if (!file.name.match(/\.(xlsx|xls|csv)$/)) {
      setError('ကျေးဇူးပြု၍ Excel (.xlsx, .xls) သို့မဟုတ် CSV ဖိုင်ကိုသာ ရွေးချယ်ပါ။');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        console.log('Parsed Excel Data:', jsonData);
        
        // Mocking a successful mapped data processing
        setTimeout(() => {
          onDataLoaded(jsonData);
          setSuccess(true);
          setIsLoading(false);
          setTimeout(() => {
            onClose();
            setSuccess(false);
          }, 1500);
        }, 1000);
      };
      reader.readAsArrayBuffer(file);
    } catch (err) {
      setError('ဖိုင်ဖတ်ရာတွင် အမှားအယွင်းရှိပါသည်။ ပြန်လည်ကြိုးစားပေးပါ။');
      setIsLoading(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-surface-container-lowest/80 backdrop-blur-sm"
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-lg bg-surface-container-low border border-outline/20 rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="p-6 border-b border-outline/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-secondary/10 rounded-lg">
                  <FileSpreadsheet className="w-5 h-5 text-secondary" />
                </div>
                <div>
                  <h3 className="text-lg font-bold myanmar-text">Excel ဒေတာ တင်သွင်းရန်</h3>
                  <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">Import Excel / CSV</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-surface-container-high rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-8">
              {!success ? (
                <div 
                  onDragOver={(e) => { e.preventDefault(); setIsDragActive(true); }}
                  onDragLeave={() => setIsDragActive(false)}
                  onDrop={onDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={cn(
                    "relative border-2 border-dashed rounded-2xl p-12 flex flex-col items-center justify-center gap-4 transition-all cursor-pointer",
                    isDragActive ? "border-secondary bg-secondary/5" : "border-outline/20 hover:border-secondary/30",
                    isLoading && "pointer-events-none opacity-50"
                  )}
                >
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    className="hidden"
                    accept=".xlsx,.xls,.csv"
                    onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                  />

                  {isLoading ? (
                    <div className="flex flex-col items-center gap-4">
                      <Loader2 className="w-12 h-12 text-secondary animate-spin" />
                      <p className="text-sm font-semibold myanmar-text">ဒေတာများကို လုပ်ဆောင်နေသည်...</p>
                    </div>
                  ) : (
                    <>
                      <div className="p-4 bg-surface-container-high rounded-full mb-2">
                        <Upload className="w-10 h-10 text-on-surface-variant/50" />
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-bold myanmar-text mb-1">ဖိုင်ကို ဤနေရာတွင် ဆွဲထည့်ပါ သို့မဟုတ် ရွေးချယ်ပါ</p>
                        <p className="text-[10px] text-on-surface-variant uppercase tracking-widest">Support: XLSX, XLS, CSV</p>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="py-12 flex flex-col items-center justify-center gap-4 text-center">
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="p-4 bg-tertiary/10 rounded-full"
                  >
                    <CheckCircle2 className="w-16 h-16 text-tertiary" />
                  </motion.div>
                  <div>
                    <h4 className="text-lg font-bold myanmar-text">ဒေတာများ အောင်မြင်စွာ တင်သွင်းပြီးပါပြီ</h4>
                    <p className="text-sm text-on-surface-variant myanmar-text">စနစ်ထဲသို့ ဒေတာများကို ထည့်သွင်းပေးထားပါသည်။</p>
                  </div>
                </div>
              )}

              {error && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 flex items-center gap-3 p-3 bg-error/10 border border-error/20 rounded-lg text-error"
                >
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <p className="text-xs font-semibold myanmar-text">{error}</p>
                </motion.div>
              )}

              <div className="mt-8 space-y-4">
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest border-b border-outline/10 pb-2">နမူနာ ကော်လံပုံစံ (Template Guide)</p>
                <div className="grid grid-cols-2 gap-3">
                  {['Building No.', 'Room No.', 'Name', 'Phone'].map(tag => (
                    <div key={tag} className="px-3 py-2 bg-surface-container-high border border-outline/30 rounded text-[9px] font-bold text-on-surface tracking-widest uppercase">
                      • {tag}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-outline/10 bg-surface-container/30 flex justify-end gap-3">
              <button 
                onClick={onClose}
                className="px-6 py-2 rounded-lg text-xs font-bold hover:bg-surface-container-high transition-colors"
                disabled={isLoading}
              >
                CANCEL
              </button>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="px-6 py-2 bg-secondary text-on-secondary rounded-lg text-xs font-bold hover:opacity-90 transition-all disabled:opacity-50"
                disabled={isLoading}
              >
                SELECT FILE
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
