import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { FileBarChart, Download, Calendar } from 'lucide-react';

const occupancyData = [
  { month: 'Jan', rate: 75 },
  { month: 'Feb', rate: 78 },
  { month: 'Mar', rate: 82 },
  { month: 'Apr', rate: 80 },
  { month: 'May', rate: 85 },
  { month: 'Jun', rate: 88 },
];

const maintenanceData = [
  { category: 'Plumbing', value: 40, color: '#2563EB' },
  { category: 'Electrical', value: 30, color: '#10B981' },
  { category: 'HVAC', value: 20, color: '#F59E0B' },
  { category: 'Others', value: 10, color: '#EF4444' },
];

export default function Reports() {
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Analytics & Reports</h2>
          <p className="text-sm text-on-surface-variant myanmar-text font-medium">
            လုပ်ငန်းဆောင်ရွက်မှု အကဲဖြတ်မှုနှင့် အစီရင်ခံစာများ
          </p>
        </div>
        
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border border-outline/30 rounded-lg text-xs font-semibold hover:bg-surface-container-high transition-colors">
            <Calendar className="w-4 h-4" /> Last 6 Months
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-secondary text-on-secondary rounded-lg text-xs font-semibold hover:opacity-90 shadow-lg shadow-secondary/20">
            <Download className="w-4 h-4" /> Export PDF
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-surface-container-low border border-outline/20 p-6 rounded-xl space-y-6">
          <h3 className="text-sm font-bold uppercase tracking-widest text-on-surface-variant">Occupancy Rate (%)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={occupancyData}>
                <defs>
                  <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#64748B20" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#c6c6cd', fontSize: 10}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#c6c6cd', fontSize: 10}} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0b1c30', border: '1px solid #64748B40', borderRadius: '8px' }}
                />
                <Area type="monotone" dataKey="rate" stroke="#2563EB" fillOpacity={1} fill="url(#colorRate)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-surface-container-low border border-outline/20 p-6 rounded-xl space-y-6">
          <h3 className="text-sm font-bold uppercase tracking-widest text-on-surface-variant">Maintenance Categories</h3>
          <div className="h-64 flex items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={maintenanceData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {maintenanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0b1c30', border: '1px solid #64748B40', borderRadius: '8px' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="w-1/3 space-y-4">
              {maintenanceData.map((item) => (
                <div key={item.category} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{backgroundColor: item.color}} />
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold uppercase tracking-tighter">{item.category}</span>
                    <span className="text-xs font-semibold">{item.value}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
