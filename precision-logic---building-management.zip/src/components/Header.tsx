import { Search, Bell, Settings, HelpCircle, User } from 'lucide-react';

export default function Header() {
  return (
    <header className="h-16 bg-surface border-b border-outline/20 flex items-center justify-between px-8 sticky top-0 z-10">
      <div className="flex items-center flex-1 max-w-md">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
          <input
            type="text"
            placeholder="ရှာဖွေရန်..."
            className="w-full bg-surface-container-low border border-outline/30 rounded-md py-1.5 pl-10 pr-4 text-sm focus:outline-none focus:border-secondary transition-colors myanmar-text"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-full transition-colors relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full border-2 border-surface" />
        </button>
        <button className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-full transition-colors">
          <Settings className="w-5 h-5" />
        </button>
        <button className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-full transition-colors">
          <HelpCircle className="w-5 h-5" />
        </button>
        
        <div className="h-8 w-px bg-outline/20 mx-2" />
        
        <button className="flex items-center gap-2 pl-2 group">
          <div className="w-8 h-8 rounded-full overflow-hidden border border-outline/30 group-hover:border-secondary transition-colors">
            <img 
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=Admin" 
              alt="User" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </button>
      </div>
    </header>
  );
}
