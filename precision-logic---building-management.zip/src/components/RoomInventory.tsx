import { DoorOpen, Search, Filter } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const rooms = Array.from({ length: 24 }).map((_, i) => ({
  id: i + 1,
  number: `A-${101 + i}`,
  type: i % 3 === 0 ? 'SUITE' : 'STANDARD',
  status: i % 4 === 0 ? 'AVAILABLE' : 'OCCUPIED',
  resident: i % 4 === 0 ? '-' : 'John Doe',
}));

export default function RoomInventory() {
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Room Inventory</h2>
          <p className="text-sm text-on-surface-variant myanmar-text font-medium">
            အခန်းများ၏ အခြေအနေနှင့် ရရှိနိုင်မှုကို စစ်ဆေးရန်
          </p>
        </div>
      </div>

      <div className="bg-surface-container-low border border-outline/20 p-4 rounded-xl flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
          <input 
            type="text" 
            placeholder="အခန်းနံပါတ်ဖြင့် ရှာဖွေရန်..." 
            className="w-full bg-surface-container-high border border-outline/30 rounded-md py-2 pl-10 pr-4 text-xs focus:border-secondary outline-none transition-colors"
          />
        </div>
        
        <div className="flex gap-2">
          {['ALL', 'AVAILABLE', 'OCCUPIED', 'MAINTENANCE'].map(status => (
            <button key={status} className={cn(
              "px-4 py-2 border rounded-lg text-[10px] font-bold tracking-widest uppercase transition-all",
              status === 'ALL' ? "bg-secondary text-on-secondary border-secondary" : "border-outline/30 text-on-surface-variant hover:bg-surface-container-high"
            )}>
              {status}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
        {rooms.map((room) => (
          <div key={room.id} className={cn(
            "bg-surface-container-low border p-4 rounded-xl flex flex-col items-center gap-3 transition-all hover:scale-105 cursor-pointer group",
            room.status === 'AVAILABLE' ? "border-tertiary/30 hover:shadow-lg hover:shadow-tertiary/10" : "border-outline/20 hover:border-secondary/50"
          )}>
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center transition-colors shadow-inner",
              room.status === 'AVAILABLE' ? "bg-tertiary/10 text-tertiary group-hover:bg-tertiary group-hover:text-on-tertiary" : "bg-outline/10 text-on-surface-variant group-hover:bg-secondary group-hover:text-on-secondary"
            )}>
              <DoorOpen className="w-5 h-5" />
            </div>
            
            <div className="text-center">
              <span className="block text-xs font-bold">{room.number}</span>
              <span className="block text-[9px] font-bold text-on-surface-variant opacity-60 uppercase">{room.type}</span>
            </div>

            <span className={cn(
              "px-2 py-0.5 rounded-full text-[8px] font-bold uppercase",
              room.status === 'AVAILABLE' ? "bg-tertiary/10 text-tertiary" : "bg-outline/10 text-on-surface-variant"
            )}>
              {room.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
