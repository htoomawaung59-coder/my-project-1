export interface Resident {
  id: string;
  roomNumber: string;
  name: string;
  photoUrl: string;
  designation: string;
  phoneNumber: string;
  status: 'ACTIVE' | 'PENDING';
}

export interface MaintenanceTask {
  id: string;
  title: string;
  room: string;
  time: string;
  status: 'OPEN' | 'CLOSED';
}

export interface BuildingScore {
  building: string;
  score: number;
}
