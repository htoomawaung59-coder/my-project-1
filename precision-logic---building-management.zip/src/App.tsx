import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DashboardOverview from './components/DashboardOverview';
import ResidentTable from './components/ResidentTable';
import MaintenanceTasks from './components/MaintenanceTasks';
import HealthChart from './components/HealthChart';
import BuildingDirectory from './components/BuildingDirectory';
import RoomInventory from './components/RoomInventory';
import Reports from './components/Reports';

export default function App() {
  const [currentView, setCurrentView] = useState('dashboard');

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <div className="space-y-8">
            <DashboardOverview />
            <ResidentTable />
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
              <div className="lg:col-span-2">
                <MaintenanceTasks />
              </div>
              <div className="lg:col-span-3">
                <HealthChart />
              </div>
            </div>
          </div>
        );
      case 'directory':
        return <BuildingDirectory />;
      case 'residents':
        return <ResidentTable />;
      case 'rooms':
        return <RoomInventory />;
      case 'reports':
        return <Reports />;
      default:
        return <DashboardOverview />;
    }
  };

  return (
    <div className="flex min-h-screen bg-surface font-sans">
      <Sidebar currentView={currentView} onNavigate={setCurrentView} />
      
      <main className="flex-1 ml-64 min-w-0 flex flex-col">
        <Header />
        
        <div className="p-8 flex-1 overflow-y-auto max-w-7xl w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {renderView()}
            </motion.div>
          </AnimatePresence>
        </div>
        
        <footer className="mt-auto p-8 border-t border-outline/10 text-center">
          <p className="text-[10px] text-on-surface-variant font-medium uppercase tracking-widest">
            © 2026 MGE.BDG Precision Logic System • All Rights Reserved
          </p>
        </footer>
      </main>
    </div>
  );
}



